﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controller : MonoBehaviour {

    public float moveSpeed;
    public float jumpForce;
    private Rigidbody2D myRidgedBody;

    public bool grounded;
    public LayerMask WhatIsGround;

    private Collider2D myCollider;


    private Animator myAnimator;
	// Use this for initialization
	void Start () {
        myRidgedBody = GetComponent<Rigidbody2D>();

        myCollider = GetComponent<Collider2D>();

        myAnimator = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {


        grounded = Physics2D.IsTouchingLayers(myCollider, WhatIsGround);

        myRidgedBody.velocity = new Vector2(moveSpeed, myRidgedBody.velocity.y);

        if (Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0) )
        {
            if (grounded)
            {
                    myRidgedBody.velocity = new Vector2(myRidgedBody.velocity.x, jumpForce);
            }
        }

        myAnimator.SetFloat("Speed", myRidgedBody.velocity.x);
        myAnimator.SetBool("Grounded", grounded);
        

	}
}
