﻿using UnityEngine;
using System.Collections;

public class platformGenerator : MonoBehaviour {

	public GameObject thePlatform;
	public Transform generationPoint;
	public float distanceBetween;

	private float platformWidth;

    public float distanceBetweenMin;
    public float distanceBetweenMax;


    public GameObject[] thePlatforms;
    private int platforSelector;
    private float[] platformWidhs;

	// Use this for initialization
	void Start () {

        //platformWidth = thePlatform.GetComponent<BoxCollider2D> ().size.x;

        platformWidhs = new float[thePlatforms.Length];

        for (int i=0; i< thePlatforms.Length; i++)
        {
            platformWidhs[i] = thePlatforms[i].GetComponent<BoxCollider2D>().size.x;
        }

	}
	
	// Update is called once per frame
	void Update () {
	
		if (transform.position.x < generationPoint.position.x)
        {
            distanceBetween = Random.Range(distanceBetweenMin, distanceBetweenMax);

            platforSelector = Random.Range(0, thePlatforms.Length);

            transform.position = new Vector3 (transform.position.x + platformWidhs [platforSelector] + distanceBetween, transform.position.y, transform.position.z);

           

			Instantiate (/*thePlatform*/thePlatforms[platforSelector], transform.position, transform.rotation);
		}
	
}
}
